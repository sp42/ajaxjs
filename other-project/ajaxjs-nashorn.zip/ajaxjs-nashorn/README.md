#Nashorn for Java 7
JS 引擎 Nashorn 本来是 Java 8 提供的，现在做到 Java 7 下支持（有点 bug）
参见[《Java 7 可运行的 Nashorn，代替 Rhino》](http://blog.csdn.net/zhangxin09/article/details/50494077) 。