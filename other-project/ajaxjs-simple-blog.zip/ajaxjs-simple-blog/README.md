小清新的 web 项目 
=================================== 

特点：简单、清新
- 前端只是写几个 function，没有依赖 jQ 等的库
- 基于 Servlet 3.0 注解的微型 MVC 
- 用户账号采用 HTTP BasicAuth，简单
- 提供一个有分类的文章发布系统，基于 RESTful 的增删改查，数据库是文件数据库 SQLite
- SQL 语句 + JDBC

