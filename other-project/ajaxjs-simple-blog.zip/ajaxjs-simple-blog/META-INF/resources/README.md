link folder should be renamed before exporting JAR file.
