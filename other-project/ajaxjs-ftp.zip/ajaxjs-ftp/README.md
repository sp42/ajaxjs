#FTP 文件上传
------------
纯 Java 项目，基于 sun.net.ftp.FtpClient 的封装（OpenJDK 1.6 源码），可支持安卓环境，支持进度条。

参见[《Java 轻量级调用 FTP 上传（安卓可用）》](http://blog.csdn.net/zhangxin09/article/details/51360874)