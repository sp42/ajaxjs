package com.egdtv.crawler;

public interface Constant {
	public static final String[] crawlerTypes = new String[]{"视频","音频","文章"};
	public static final String rmiService = "rmi://192.168.1.136:8888/rmiService";
}
