package com.egdtv.crawler.model;

import com.ajaxjs.framework.model.EntityDescription;
import com.ajaxjs.framework.model.FieldDescription;

@EntityDescription(doc="视频，格式可以是 mp4、m3u8 等等", extraHTML_path="/show_video/document.jsp")
public class Video extends NetItem {
//	@FieldDescription(doc="高清的播放源地址") 
//	private String sourceUrl_hi;
//	
//	@FieldDescription(doc="超清的播放源地址") 
//	private String sourceUrl_super;
//	
//	@FieldDescription(doc="原画的播放源地址") 
//	private String sourceUrl_orgin;
//
//	public String getSourceUrl_hi() {
//		return sourceUrl_hi;
//	}
//
//	public void setSourceUrl_hi(String sourceUrl_hi) {
//		this.sourceUrl_hi = sourceUrl_hi;
//	}
//
//	public String getSourceUrl_super() {
//		return sourceUrl_super;
//	}
//
//	public void setSourceUrl_super(String sourceUrl_super) {
//		this.sourceUrl_super = sourceUrl_super;
//	}
//
//	public String getSourceUrl_orgin() {
//		return sourceUrl_orgin;
//	}
//
//	public void setSourceUrl_orgin(String sourceUrl_orgin) {
//		this.sourceUrl_orgin = sourceUrl_orgin;
//	}
}
