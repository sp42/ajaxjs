package com.egdtv.crawler.model;

import com.ajaxjs.framework.model.EntityDescription;

/**
 * 音频
 * @author frank
 *
 */
@EntityDescription(doc="音频，格式可以是 mp3、m4a 等等")
public class Audio extends NetItem {
	
}
