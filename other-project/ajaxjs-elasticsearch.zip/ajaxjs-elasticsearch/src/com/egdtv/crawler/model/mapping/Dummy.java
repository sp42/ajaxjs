package com.egdtv.crawler.model.mapping;

public class Dummy {

}
