bf_Config = {
	clientFullName : "头条影音采集系统",
	clientShortName : "采集系统",
	app : {
		isUsingMySQL : true
	},
	site : {
		titlePrefix : "头条影音采集系统",
		keywords : "采集系统",
		description : "头条影音采集系统",
		footCopyright:"smc"
	}
};
  