JSP 页面管理器
=================================== 
参见 ：http://blog.csdn.net/zhangxin09/article/details/51545128