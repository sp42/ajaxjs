package com.ajaxjs.framework.controller;

import com.ajaxjs.mvc.model.BaseModel;

public class AdminController<T extends BaseModel> extends AbstractController<T> {

}
