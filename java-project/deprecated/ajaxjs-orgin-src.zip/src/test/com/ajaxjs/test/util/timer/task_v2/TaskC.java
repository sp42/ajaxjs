package com.ajaxjs.test.util.timer.task_v2;

public class TaskC {
	public static void main(String[] args) {
		System.out.println("task c test");
	}

	public static void testC() {
		System.out.println("Taskc testC method call!");
	}
}
