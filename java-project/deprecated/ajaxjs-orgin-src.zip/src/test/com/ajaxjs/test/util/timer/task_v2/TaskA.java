package com.ajaxjs.test.util.timer.task_v2;

public class TaskA {
	public static void main(String[] args) {
		System.out.println("task a test");
	}

	public static void testA() {
		System.out.println("taska testA method call!");
	}
}
