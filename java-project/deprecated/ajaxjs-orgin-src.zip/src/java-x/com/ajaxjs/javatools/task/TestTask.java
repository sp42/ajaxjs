package com.ajaxjs.javatools.task;

/**
 * 测试用例
 * @author frank
 *
 */
public class TestTask implements Runnable {  
    public void run(){  
    	System.out.println("time===" + System.currentTimeMillis());  
    }  
} 