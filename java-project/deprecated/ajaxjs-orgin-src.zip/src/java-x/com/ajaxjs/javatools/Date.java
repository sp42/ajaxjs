package com.ajaxjs.javatools;

public class Date {

}
