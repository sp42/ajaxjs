package com.ajaxjs.javatools.net.pagecache.cache;

import java.util.Map;

public class MemCacheStore implements CacheStore {
	@Override
	public void init(Map<String, String> initParams) {
	}

	@Override
	public void put(String key, String value, String urlPattern) {
	}

	@Override
	public String get(String key) {
		return null;
	}
}
