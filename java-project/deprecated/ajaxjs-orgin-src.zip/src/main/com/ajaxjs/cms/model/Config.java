package com.ajaxjs.cms.model;

public class Config {
	private boolean siteStatus_pc;

	public boolean isSiteStatus_pc() {
		return siteStatus_pc;
	}

	public void setSiteStatus_pc(boolean siteStatus_pc) {
		this.siteStatus_pc = siteStatus_pc;
	}
	
}
