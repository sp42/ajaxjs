package com.ajaxjs.framework.controller;


import com.ajaxjs.framework.model.BaseModel;

public class AdminController<T extends BaseModel> extends AbstractController<T> {

	 

}
