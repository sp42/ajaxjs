package com.ajaxjs.net.upload;

public class UploadException extends Exception {

	private static final long serialVersionUID = 579958777177500819L;

	public UploadException(String msg) {
		super(msg);
	}

}
