package com.ajaxjs.net.http;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.GZIPInputStream;

import com.ajaxjs.util.IO;
import com.ajaxjs.util.LogHelper;
import com.ajaxjs.Constant;

public class Get {
	private static final LogHelper LOGGER = LogHelper.getLog(Get.class);
	
	/**
	 * 简单 GET 请求（原始 API 版），返回文本。
	 * 
	 * @param url
	 *            请求目标地址
	 * @return 响应内容（如 HTML，JSON 等）
	 */
	public static String simpleGET(String url) {
		try {
			return RequestClient.stream2String(new URL(url).openStream(), Constant.encoding_UTF8);
		} catch (IOException e) {
			LOGGER.warning("请求出错" + url, e);
			return null;
		}
	}

	/**
	 * 简单 GET 请求，返回文本。
	 * 
	 * @param url
	 *            请求目标地址
	 * @return 响应内容（如 HTML，JSON 等）
	 */
	public static String GET(String url) {
		Request req = new Request();
		req.setUrl(url);
	
		RequestClient rc = new RequestClient(req);
		try {
			rc.connect();
		} catch (ConnectException e) {
			LOGGER.warning("请求出错" + url, e);
			
			return null;
		}
		
		return req.getFeedback();
	}

	/**
	 * 得到 HTTP 302 的跳转地址
	 * 
	 * @param url
	 *            目标地址
	 * @return 跳转地址
	 */
	public static String get302redirect(String url) {
		String redirectTo = Get.initHEAD_reqeust(url).getConnection().getHeaderField("Location");
		return redirectTo;
	}

	/**
	 * 检测资源是否存在
	 * 
	 * @param url
	 *            目标地址
	 * @return true 表示 404 不存在
	 */
	public static boolean is404(String url) {
		RequestClient rc = Get.initHEAD_reqeust(url);
		try {
			return rc.getConnection().getResponseCode() == 404;
		} catch (IOException e) {
			LOGGER.warning(e);
			return true;
		}
	}

	/**
	 * 得到资源的文件大小
	 * 
	 * @param url
	 *            目标地址
	 * @return 文件大小
	 */
	public static long getFileSize(String url) {
		RequestClient rc = Get.initHEAD_reqeust(url);
		String contentLength = rc.getConnection().getHeaderField("content-length");
		return Long.parseLong(contentLength);
	}
	
	/**
	 * 获取远程资源的大小 （另外一种写法，可参考之）
	 * 
	 * @param url
	 *            目标地址
	 * @return 文件大小
	 */
	public static long getRemoteSize(String url) {
		long size = 0;

		try {
			HttpURLConnection conn = (HttpURLConnection) (new URL(url)).openConnection();
			size = conn.getContentLength();
			conn.disconnect();
		} catch (IOException e) {
			LOGGER.warning(e);
		}

		return size;
	}

	/**
	 * 创建一个 HEAD 请求
	 * 
	 * @param url
	 *            目标地址
	 * @return
	 */
	private static RequestClient initHEAD_reqeust(String url) {
		Request req = new Request();
		req.setUrl(url);
		req.setMethod("HEAD");
		RequestClient rc = new RequestClient(req);
		rc.getConnection().setInstanceFollowRedirects(false); // 必须设置false，否则会自动redirect到Location的地址
		
		try {
			rc.connect();
		} catch (ConnectException e) {
			LOGGER.warning("HEAD 请求出错" + url, e);
		}
		
		return rc;
	}
	
	/**
	 * 下载任意 web 文件到本地 
	 * 
	 * @param url
	 *            目标地址
	 * @param filePathName
	 *            保存本地的完整路径
	 */
	public static void download2disk(String url, final String filePathName) {
		Request req = new Request();
		req.setUrl(url);
		final RequestClient rc = new RequestClient(req);

		req.setCallback(new Request.Callback() {
			@Override
			public void onDataLoad(InputStream is) {
				if ("gzip".equals(rc.getConnection().getHeaderField("Content-Encoding"))) {
					try {
						IO.save2file(filePathName, new GZIPInputStream(is)); // 自动处理图片是否经过服务器gzip压缩的问题
					} catch (IOException e) {
						LOGGER.warning(e);
					}
				} else {
					IO.save2file(filePathName, is);
				}
			}
		});

		try {
			rc.connect();
		} catch (ConnectException e) {
			LOGGER.warning(e);
		}
	}

	/**
	 * 断点下载文件
	 * 
	 * @param url
	 *            目标地址
	 * @param filePathName
	 *            保存本地的完整路径
	 * @param startPos
	 *            开始位置
	 */
	public static void download2disk(String url, String filePathName, long startPos) {
		try {
			HttpURLConnection httpConnection = (HttpURLConnection) (new URL(url)).openConnection();
			// 设置User-Agent
			httpConnection.setRequestProperty("User-Agent", "NetFox");
			// 设置断点续传的开始位置
			httpConnection.setRequestProperty("RANGE", "bytes=" + startPos);
	
			byte[] b = new byte[1024];
			int nRead;
	
			// 获得输入流
			try (RandomAccessFile oSavedFile = new RandomAccessFile(filePathName, "rw");
				InputStream input = httpConnection.getInputStream();) {
				oSavedFile.seek(startPos);	// 定位文件指针到nPos位置
				
				while ((nRead = input.read(b, 0, 1024)) > 0) { // 从输入流中读入字节流，然后写到文件中
					oSavedFile.write(b, 0, nRead);
				}
			}
	
			httpConnection.disconnect();
	 
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 基本原理：利用URLConnection获取要下载文件的长度、头部等相关信息，并设置响应的头部信息。并且通过URLConnection获取输入流，将文件分成指定的块，每一块单独开辟一个线程完成数据的读取、写入。通过输入流读取下载文件的信息，然后将读取的信息用RandomAccessFile随机写入到本地文件中。同时，每个线程写入的数据都文件指针也就是写入数据的长度，需要保存在一个临时文件中。这样当本次下载没有完成的时候，下次下载的时候就从这个文件中读取上一次下载的文件长度，然后继续接着上一次的位置开始下载。并且将本次下载的长度写入到这个文件中。 
	 * Java 多线程断点下载文件 http://blog.csdn.net/ycb1689/article/details/8229585
	 */
	public static void multi_line_download(){}

	public static void bigDown() {
		String url = "http://www.videosource.cgogo.com/media/0/16/8678/8678.flv";
		String savePath = "F:\\";
		String fileName = url.substring(url.lastIndexOf("/"));
		String fileNam = fileName;
	
		File file = new File(savePath + fileName);
		// 获得远程文件大小
		long remoteFileSize = getRemoteSize(url);
		System.out.println("远程文件大小=" + remoteFileSize);
	
		int i = 0;
		if (file.exists()) {
			// 先看看是否是完整的，完整，换名字，跳出循环，不完整，继续下载
			long localFileSize = file.length();
			System.out.println("已有文件大小为:" + localFileSize);
	
			if (localFileSize < remoteFileSize) {
				System.out.println("文件续传");
				download2disk(url, savePath + fileName, localFileSize);
			} else {
				System.out.println("文件存在，重新下载");
				do {
					i++;
					fileName = fileNam.substring(0, fileNam.indexOf(".")) + "(" + i + ")"
							+ fileNam.substring(fileNam.indexOf("."));
	
					file = new File(savePath + fileName);
				} while (file.exists());
				try {
					file.createNewFile();
				} catch (IOException e) {
					e.printStackTrace();
				}
				download2disk(url, savePath + fileName, 0);
			}
			// 下面表示文件存在，改名字
	
		} else {
			try {
				file.createNewFile();
				System.out.println("下载中");
				download2disk(url, savePath + fileName, 0);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
