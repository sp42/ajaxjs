package com.ajaxjs.business.model;

import com.ajaxjs.framework.model.Entity;

public class News extends Entity {

}
