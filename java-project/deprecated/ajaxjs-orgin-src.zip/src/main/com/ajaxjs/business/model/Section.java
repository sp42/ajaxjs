package com.ajaxjs.business.model;

public class Section extends Catalog {

}
