package com.ajaxjs.util.db.mybatis;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

public class MapResult<T> implements ResultHandler<T>  {

	@Override
	public void handleResult(ResultContext<? extends T> arg0) {
		// TODO Auto-generated method stub
	}

}
