package com.ajaxjs.net.http;

public class Server {

}
