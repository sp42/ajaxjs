package com.ajaxjs.net.socket;

public class A {

}
