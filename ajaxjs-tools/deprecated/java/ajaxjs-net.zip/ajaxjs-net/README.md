# AJAXJS-Net
Usage:

	<dependency>
	    <groupId>com.ajaxjs</groupId>
	    <artifactId>ajaxjs-net</artifactId>
	    <version>1.0.1</version>
	</dependency>

AJAXJS Framework 之 Net 包，网络通讯类，包含以下子模块：

- http 可发送 GET/POST/PUT/DELETE 请求。远没有 Apache HttpClient 完善，但足以满足一般的请求；
- mail 无须 JavaMail 发送邮件。原理是通过最简单的 telnet 发送；
- ip IP 工具类

[>>详细用法参见手册](http://ajaxjs.mydoc.io/?t=203095)。


FTP 文件上传
------------
纯 Java 项目，基于 sun.net.ftp.FtpClient 的封装（OpenJDK 1.6 源码），可支持安卓环境，支持进度条。

参见[《Java 轻量级调用 FTP 上传（安卓可用）》](http://blog.csdn.net/zhangxin09/article/details/51360874)

版权声明 LICENSE
==========
作者版权所有，开源许可：Apache License, Version 2.0