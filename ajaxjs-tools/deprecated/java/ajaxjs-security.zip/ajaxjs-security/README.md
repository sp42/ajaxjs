# AJAXJS-Security
安全框架，提供 XSS 等防御