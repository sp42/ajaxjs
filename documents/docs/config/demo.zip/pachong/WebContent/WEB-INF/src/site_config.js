bf_Config = {
	site : {
		titlePrefix : "容祯的自留地",
		keywords : "日记",
		description : "Frank 之日记",
		footCopyright:"smc"
	}
};
 